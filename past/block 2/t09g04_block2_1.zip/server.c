#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <time.h>

int main(int argc, char *argv[]) 
{
	//init variables
	int sockfd, secondsockfd, portno;
	socklen_t socklen;
	char reply[256];
	struct sockaddr_in serv_addr, client_addr;
	int n;
	
	if(argc != 3)
	{
		printf("Usage: ./server port txtpath\n");
		exit(1);
	}
	//socket()
	sockfd = socket(PF_INET, SOCK_STREAM, 0);
	//important infos of the server
	portno = atoi(argv[1]);
	serv_addr.sin_family = AF_INET;
    serv_addr.sin_addr.s_addr = INADDR_ANY;
    serv_addr.sin_port = htons(portno);
	memset(serv_addr.sin_zero, '\0', sizeof serv_addr.sin_zero);
    //enable many binds in a close timerange -> tell kernel to re-use port
    int useSockAgain = 1;
    setsockopt(sockfd, SOL_SOCKET, SO_REUSEADDR, &useSockAgain, sizeof(useSockAgain));
	//bind()
	if(bind(sockfd,(struct sockaddr *) &serv_addr, sizeof serv_addr) == -1)
	{
		printf("binding failed\n");
		exit(1);	
	}
	//listen()
	listen(sockfd,2);

	socklen = sizeof client_addr;
	//accept()
	secondsockfd = accept(sockfd, (struct sockaddr *) &client_addr, &socklen);
	if(secondsockfd == -1)
	{
		printf("accept failed\n");
		exit(1);
	}
	//recv()
	n = recv(secondsockfd, reply, 255,0);
	if(n == -1)
	{
		printf("recv failed\n");
		exit(1);
	}


	printf("client sended message");
	printf("\ngiven path: %s\n", argv[2]);
	
	//get txt line
	FILE* fp;
	FILE* fp2;
	char ch;
	int filelines = 0;
	fp = fopen(argv[2], "r");
	while(!feof(fp))
	{
  		ch = fgetc(fp);
  		if(ch == '\n')
		{
    		filelines++;
  		}
	}
	fclose(fp);
	fp2 = fopen(argv[2], "r");
	//generate random number between 0 and maximum number of lines in txt
	srand(time(NULL));
	int line = rand() % filelines;

	//gets random line and put it into server_reply
	int count = 0;
	if ( fp2 != NULL )
    {
        while (fgets(reply, sizeof reply, fp2) != NULL) /* read a line */
        {   
            if (count == line)
            {
            fclose(fp2);
            }   
            else
            {   
                count++;
            }   
        }
    }
	//random line saved


	//send() random line
	n = send(secondsockfd, reply, 255, 0);
	if(n == -1)
	{
		printf("send failed\n");
		exit(1);
	}
	//close
	close(secondsockfd);
	close(sockfd);
	return 0;
}










