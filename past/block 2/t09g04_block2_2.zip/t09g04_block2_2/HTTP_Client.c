#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>

/*
void searchMsg(char array[], char Tag[], lenMsg, char buffer[]){
    
        search for word in array and return message after the Tag in buffer
    
}
*/
int main(int argc, char *argv[]) {
	printf("ACHTUNG: kompilieren mit std=gnu99\n");
	if(argc != 3){
		printf("%d Usage: ./tcpclient hostname port\n", argc);
		exit(1);
	}

	//init variables
    int sockfd;
    int port = atoi(argv[2]);
    struct sockaddr_in their_addr;
    struct hostent *he;
    char msg[256];
	strcpy(msg, "GET /index.php?id=8339&type=100 HTTP/1.1\nHOST: www.ub.tu-berlin.de\n\n");
    char server_reply[25000];
    FILE *fp;
	
	//save hostname in he
    he = gethostbyname(argv[1]);
	//socket()
    if ((sockfd = socket(AF_INET, SOCK_STREAM, 0)) == -1) {
        perror("socket");
        exit(1);
    }
	//save all important server infos in their_addr
    their_addr.sin_family = AF_INET;
    their_addr.sin_port = htons(port);
    their_addr.sin_addr = *((struct in_addr *)he->h_addr_list[0]);
    memset(their_addr.sin_zero, '\0', sizeof their_addr.sin_zero);

    //connect()
    if(connect(sockfd, (struct sockaddr *)&their_addr, sizeof their_addr) == -1){
		perror("connect");
		exit(1);
	}
    //send()
    if(send(sockfd, msg, strlen(msg), 0) == -1)
	{
		printf("sending failed\n");
		exit(1);
	}

    fp = fopen("text.txt", "w");
    if(fp == NULL){
        printf("File creation failed!");
        return -1;
    }

    //recv() and write received message in xml file
    int received;
    while(received <= 24049) {
      memset(server_reply, '\0', sizeof server_reply);
      received += recv(sockfd, server_reply, sizeof server_reply, 0);
      fputs(server_reply, fp);
    }
	//find and print requested informations
	//fint title
	FILE* fp2;
	int dontDouble = 0;
	char title[512];
	char *tok;
	fp2 = fopen("text.txt", "r");
	while(!feof(fp2))
	{
		fgets(title, sizeof title, fp2);
		if(strstr(title, "<item>") && dontDouble == 0)
		{
			dontDouble++;
		}
		if(strstr(title, "<title>") && dontDouble > 0)
		{
			tok = strtok(title, ">");
			tok = strtok(NULL, "<");
			printf("Titel: %s\n", tok);
			dontDouble++;
		}
		if(strstr(title, "<link>") && dontDouble > 0)
		{
			tok = strtok(title, ">");
			tok = strtok(NULL, "<");
			printf("Link: %s\n", tok);
			dontDouble++;
		}
		if(strstr(title, "<description>") && dontDouble > 0)
		{
			tok = strtok(title, ">");
			tok = strtok(NULL, "<");
			printf("Beschreibung: %s\n", tok);
			dontDouble++;
		}
		if(strstr(title, "<pubDate>")&& dontDouble > 0)
		{
			tok = strtok(title, ">");
			tok = strtok(NULL, "<");
			printf("Datum: %s\n", tok);
			dontDouble++;
		}
		if(dontDouble == 5) break;
	}
    
    fclose(fp2);
    fclose(fp);

    //close()
    close(sockfd);
    return 0;
}
