#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <time.h>








int main(int argc, char *argv[]) {
	printf("ACHTUNG: kompilieren mit std=gnu99\n");

	if(argc != 3){
		printf("%d Usage: ./tcpclient hostname port\n", argc);
		exit(1);
	}

	//init variables
    int sockfd;
    int port = atoi(argv[2]);
    struct sockaddr_in their_addr;
    struct hostent *he;
    char msg[256];
	strcpy(msg, "Client was here wuhuuuuu");
    char server_reply[256];
	
	//save hostname in he
    he = gethostbyname(argv[1]);
	//socket()
    if ((sockfd = socket(AF_INET, SOCK_DGRAM, 0)) == -1) {
        perror("socket");
        exit(1);
    }
	//save all important server infos in their_addr
    their_addr.sin_family = AF_INET;
    their_addr.sin_port = htons(port);
    their_addr.sin_addr = *((struct in_addr *)he->h_addr);
    memset(their_addr.sin_zero, '\0', sizeof their_addr.sin_zero);
    //sendto()
	//start recording time for data exchange
	struct timespec start;
	struct timespec end;
	clock_gettime(CLOCK_REALTIME, &start);
    if(sendto(sockfd, msg, strlen(msg), 0, (struct sockaddr*) &their_addr, sizeof their_addr) == -1)
	{
		printf("sending failed\n");
		exit(1);
	}
    //recvfrom()
	struct sockaddr_storage addr;
	socklen_t len;
    recvfrom(sockfd, server_reply, 256, 0, (struct sockaddr*) &addr, &len);
    printf("%s\n", server_reply);
	clock_gettime(CLOCK_REALTIME, &end);
	long int time_elapsed = end.tv_nsec - start.tv_nsec;
	if(time_elapsed < 0) time_elapsed = time_elapsed + 1000000000;
	printf("time elapsed for TCP: %ldns\n", time_elapsed);
   
    //close()
    close(sockfd);
    return 0;
}
