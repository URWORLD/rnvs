Es kann sein, dass beim ersten set befehl der key komische zeichen rangeh�ngt bekommt (z.B aus key "test key" wird "test key&^?"), diese dann
den hash beeinflussen und der dadurch nicht korrekt gespeichert wird. In den meisten f�llen l�st sich dieser fehler von selbst auf, aber bitte im Hinterkopf behalten.
Ab dem zweiten set befehl sollte alles fl�ssig funktionieren.