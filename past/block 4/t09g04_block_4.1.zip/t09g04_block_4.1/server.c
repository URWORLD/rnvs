#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <time.h>

/****************************************************
*************BEGIN OF HASHFUNCTIONS******************
****************************************************/
#define SIZE 512

struct HashElem{
	unsigned char *key;
	unsigned char *value;
	struct HashElem *next;
};

struct HashElem* ht[SIZE];

int hash(unsigned char *str)
{
	unsigned long hash = 5381 * str[0] * str [1];
  int c;
  while ((c = *str++)) hash = ((hash << 5) + hash) + c;    /* hash * 33 + c */
  if(hash < 0) return (hash * -1) % 512;
  return hash % 512;
}

struct HashElem *get(unsigned char *key, unsigned char *value)
{
	printf("GET\n");
	int index = hash(key);
	struct HashElem *elem = (struct HashElem*) malloc(sizeof(struct HashElem));
	elem->key = malloc( sizeof( unsigned char ) * 256 );
	elem->value = malloc(sizeof(unsigned char) * 256);
	if(ht[index] == NULL) return NULL;
	elem = ht[index];
	elem->value = ht[index]->value;
	elem->key = ht[index]->key;
	while(elem != NULL)
	{
		if(memcmp(elem->key, key, sizeof(&key)) == 0){
			return elem;
		}
		elem = elem->next;
	}
	return NULL;
}

int set(unsigned char *key, unsigned char* value){
	printf("SET\n");
	// printf("keylen: %lu, valuelen: %lu\n", sizeof(key), sizeof(value));
	printf("keylen: %zu, valuelen: %zu\n", strlen((char*)key), strlen((char*)value));
	//to iterate
	int index = hash(key);
	struct HashElem *newelem = (struct HashElem*) malloc(sizeof(struct HashElem));
	newelem->next = NULL;
	//fehler

	//newelem->key = malloc(sizeof(unsigned char) * 512);
	newelem->key = malloc(512);
	//memcpy(newelem->key, key, sizeof(&key));
	memcpy(newelem->key, key, strlen((char*)key));

	//newelem->value = malloc(sizeof(char) * 512);
	newelem->value = malloc(512);
	//memcpy(newelem->value, value, sizeof(&value));
	memcpy(newelem->value, value, strlen((char*)value));

	if(ht[index] == NULL)
	{
		printf("no element at index\n");
		ht[index] = newelem;
		printf("Stored new element at index\n");
		return 0;
	}
	struct HashElem *curr = (struct HashElem*) malloc(sizeof(struct HashElem));
	curr->next = ht[index]->next;
	curr->key = malloc(sizeof(unsigned char) * 512);
	memcpy(curr->key, ht[index]->key, sizeof(&ht[index]->key));
	curr->value = malloc(sizeof(char) * 512);
	memcpy(curr->value, ht[index]->value, sizeof(&value));
	if(memcmp(ht[index]->key, key, sizeof(&key)) == 0)
	{
		printf("key already exists, replace value\n");
		memcpy(ht[index]->value, value, sizeof(&value));
		printf("Updated element at index\n");
		return 0;
	}
	while(curr->next != NULL)
	{
		if(memcmp(curr->next->key, key, sizeof(&key)) == 0)
		{
			printf("key already exists, replace value");
			memcpy(curr->next->value, value, sizeof(&value));
			return 0;
		}
		curr = curr->next;
	}
	printf("unique key, insert value\n");
	curr->next = newelem;
	return 0;
}

struct HashElem del(struct HashElem *elem)
{
	printf("DEL\n");
	struct HashElem *curr = (struct HashElem*) malloc(sizeof(struct HashElem));
	curr->key = malloc( sizeof( unsigned char ) * 100 );
	curr->value = malloc(sizeof(char) * 100);
	struct HashElem *prev = (struct HashElem*) malloc(sizeof(struct HashElem));
	prev->key = malloc( sizeof( unsigned char ) * 100 );
	prev->value = malloc(sizeof(char) * 100);
	unsigned char* key = elem->key;

  //get the hash
  int index = hash(key);
	curr = ht[index];
	prev =curr;
	if(curr == NULL) return *elem;
	if(curr->next == NULL){
		ht[index] = NULL;
		return *elem;
	}
    while(curr != NULL)
	{
		if(memcmp(elem->key, key, sizeof(&key)) == 0)
		{
			printf("delete element\n");
			prev->next = curr->next;
			free(curr);
			return *elem;
		}
		//go to next cell
		prev = curr;
		curr = curr->next;
	}
	return *elem;
}

/****************************************************
*************END OF HASHFUNCTIONS********************
***********BEGIN OF CHORD FUNCTIONS******************
****************************************************/

int succ, pred, myport, myid;
struct sockaddr_in succ_addr;
struct sockaddr_in   my_addr;
struct sockaddr_in pred_addr;
//used to  send message back to direct sender
struct sockaddr_in recv_addr;

//recv stabilize and change my pred
int recv_stabilize(unsigned char msg[])
{
	printf("received stabilize\n");
	struct hostent *he;

	char ip_num[4];
	char ip_str[16];
	ip_num[0] = msg[1];
	ip_num[1] = msg[2];
	ip_num[2] = msg[3];
	ip_num[3] = msg[4];
	int pred_port = msg[5]*256 + msg[6];
	inet_ntop(AF_INET, ip_num, ip_str, INET6_ADDRSTRLEN);
	pred = msg[7]*256 + msg[8];
	he = gethostbyname(ip_str);
	pred_addr.sin_family = AF_INET;
	pred_addr.sin_port = htons(pred_port);
	pred_addr.sin_addr = *((struct in_addr *)he->h_addr);
	memset(pred_addr.sin_zero, '\0', sizeof pred_addr.sin_zero);
	//now send notify to new pred
	printf("new pred: %d   id: %d   ip: %s\n", pred_port, pred, ip_str);
	return 0;
}


//send my infos to a new succ
int stabilize(unsigned char msg[])
{
	printf("stabilize\n");
	int sockfd;
	//send succ stabilize with my infos
	//socket()
	if ((sockfd = socket(AF_INET, SOCK_DGRAM, 0)) == -1) {
		perror("socket");
		exit(1);
	}
	//sendto()
	if(sendto(sockfd, msg, 9, 0, (struct sockaddr*) &succ_addr, sizeof succ_addr) == -1)
	{
		printf("sending failed(recv_join)\n");
		exit(1);
	}
	close(sockfd);
	return 0;
}

int notify(unsigned char msg[])
{
	printf("notify\n");
	//change pred if prev operation was join and send notify to new pred and old pred
	if((msg[0] & 0b00000001) >= 1)
	{
		int sockfd;
		struct hostent *he;

		char ip_num[4];
		char ip_str[16];
		ip_num[0] = msg[1];
		ip_num[1] = msg[2];
		ip_num[2] = msg[3];
		ip_num[3] = msg[4];
		int pred_port = msg[5]*256 + msg[6];
		inet_ntop(AF_INET, ip_num, ip_str, INET6_ADDRSTRLEN);
		//notify old pred, that i got a new pred
		if((myid != pred) || (pred == 10000))
		{
			//socket()
			printf("send notify to my old pred\n");
			msg[0] = 128 + 2;
			if ((sockfd = socket(AF_INET, SOCK_DGRAM, 0)) == -1)
			{
			    perror("socket");
			    exit(1);
			}
			//send msg with new pred infos to old pred
			if(sendto(sockfd, msg, 9, 0, (struct sockaddr*) &pred_addr, sizeof pred_addr) == -1)
			{
				printf("sending failed in notify\n");
				exit(1);
			}

		}
		pred = msg[7]*256 + msg[8];
		he = gethostbyname(ip_str);
		pred_addr.sin_family = AF_INET;
		pred_addr.sin_port = htons(pred_port);
		pred_addr.sin_addr = *((struct in_addr *)he->h_addr);
		memset(pred_addr.sin_zero, '\0', sizeof pred_addr.sin_zero);
		//now send notify to new pred
		printf("new pred: %d   id: %d   ip: %s\n", pred_port, pred, ip_str);
		if(succ == 10000 || succ == myid)
		{
			succ = pred;
			succ_addr.sin_family = AF_INET;
			succ_addr.sin_port = htons(pred_port);
			succ_addr.sin_addr = *((struct in_addr *)he->h_addr);
			memset(succ_addr.sin_zero, '\0', sizeof succ_addr.sin_zero);
			printf("new succ: %d   id: %d   ip: %s\n", pred_port, pred, ip_str);
		}
		//socket()
		if ((sockfd = socket(AF_INET, SOCK_DGRAM, 0)) == -1)
		{
		    perror("socket");
		    exit(1);
   	}
		//sendto() and change the msg to my own informations
		char *myip_str = inet_ntoa(my_addr.sin_addr);
		inet_pton(AF_INET, myip_str, ip_num);
		msg[0] = 128 + 2;
		msg[1] = ip_num[0];
		msg[2] = ip_num[1];
		msg[3] = ip_num[2];
		msg[4] = ip_num[3];
		msg[5] = myport / 256;
		msg[6] = myport;
		msg[7] = myid / 256;
		msg[8] = myid;
		if(sendto(sockfd, msg, 9, 0, (struct sockaddr*) &pred_addr, sizeof pred_addr) == -1)
		{
			printf("sending failed in notify\n");
			exit(1);
		}
	}
	return 0;
}

int recv_join(unsigned char msg[], int my_id)
{
	// extract ID
	int recv_id = msg[7]*256 + msg[8];
	// check if ID is alredy is in ring
	if (pred == recv_id || succ == recv_id)
	{
		printf("ID already in ring.\n");
		return 0;
	}
	printf("join with id: %d \n", recv_id);
	//check if node is new pred
	//if recv_id is between pred and me or if i'm the only node in the ring
	if((myid > recv_id && recv_id > pred) || (myid == pred))
	{
		notify(msg);
		return 0;
	}
	//if pred > myid
	else if((pred > myid && pred != 10000) && (recv_id > pred || recv_id < myid))
	{
		notify(msg);
		return 0;
	}
	//else send request to succ
	else if(1)
	{
		printf("Sending join request to successor\n");
		int sockfd;
		//socket()
		if ((sockfd = socket(AF_INET, SOCK_DGRAM, 0)) == -1)
		{
		  perror("socket");
		  exit(1);
		}
		//sendto()
		if(sendto(sockfd, msg, 9, 0, (struct sockaddr*) &succ_addr, sizeof succ_addr) == -1)
		{
			printf("sending failed(recv_join)\n");
			exit(1);
		}
		close(sockfd);
	}
	return 0;
}

int recv_notify(unsigned char msg[])
{
	printf("notify received from succ\n");
	int succ_port;
	char ip_succ_str[16];
	struct hostent *he;
	char ip_succ_num[4];
	//Get informations from received message
	ip_succ_num[0] = msg[1];
	ip_succ_num[1] = msg[2];
	ip_succ_num[2] = msg[3];
	ip_succ_num[3] = msg[4];
	succ_port      = msg[5] * 256 + msg[6];
	succ           = msg[7] * 256 + msg[8];
	inet_ntop(AF_INET, ip_succ_num, ip_succ_str, INET6_ADDRSTRLEN);
	he             = gethostbyname(ip_succ_str);
	succ_addr.sin_family = AF_INET;
	succ_addr.sin_port = htons(succ_port);
	succ_addr.sin_addr = *((struct in_addr *)he->h_addr);
	memset(succ_addr.sin_zero, '\0', sizeof succ_addr.sin_zero);
	printf("new succ with id: %d   ip: %s   port: %d\n", succ, ip_succ_str, succ_port);
	//TODO if new succ, tell new succ that im his new pred (call stabilize)
	if(pred != 10000)
	{
		//variables
		char *myip_str = inet_ntoa(my_addr.sin_addr);
		char ip_my_num[4];
		inet_pton(AF_INET, myip_str, ip_my_num);
		//write my infos in msg
		msg[0] = 128 + 4;
		msg[1] = ip_my_num[0];
		msg[2] = ip_my_num[1];
		msg[3] = ip_my_num[2];
		msg[4] = ip_my_num[3];
		msg[5] = myport / 256;
		msg[6] = myport;
		msg[7] = myid/256;
		msg[8] = myid;
		sleep(1);
		stabilize(msg);
	}
	if(pred == 10000)
	{
		pred = succ;
		pred_addr.sin_family = AF_INET;
		pred_addr.sin_port = htons(succ_port);
		pred_addr.sin_addr = *((struct in_addr *)he->h_addr);
		memset(pred_addr.sin_zero, '\0', sizeof pred_addr.sin_zero);
		printf("new pred with id: %d   ip: %s   port: %d\n", succ, ip_succ_str, succ_port);
	}

	return 0;
}

int join(struct sockaddr_in join_addr, int id, unsigned char msg[])
{
	int sockfd;
	//TODO: send join msg to join_addr
	//socket()
    if ((sockfd = socket(AF_INET, SOCK_DGRAM, 0)) == -1) {
        perror("socket");
        exit(1);
    }
	//bind
	if(bind(sockfd,(struct sockaddr *) &my_addr, sizeof my_addr) == -1)
	{
		printf("binding failed\n");
		exit(1);
	}
	//sendto()
    if(sendto(sockfd, msg, 9, 0, (struct sockaddr*) &join_addr, sizeof join_addr) == -1)
	{
		printf("sending failed (join)\n");
		exit(1);
	}
    //recvfrom()
	struct sockaddr_storage addr;
	socklen_t len;
    recvfrom(sockfd, msg, 9, 0, (struct sockaddr*) &addr, &len);
	//check if notify msg is received
	if(((msg[0] & 0b00000010) >= 1) && ((msg[0] & 0b10000000) >= 1)) recv_notify(msg);
	close(sockfd);
	return 0;
}

int main(int argc, char *argv[])
{
	//init variables
	int sockfd, secondsockfd, ringport, n;
	unsigned char reply[1024];
	unsigned char intern[9];
	struct sockaddr_in join_addr;
  struct hostent *he;
	struct hostent *he_client;
	if(argc < 3 || argc > 7)
	{
		printf("Usage: ./server address port (ID second_address second_port)\n");
		exit(1);
	}
	//first step: join the circle
	if(argc > 4)
	{
		printf("Node\n");
		myport = atoi(argv[2]);
		my_addr.sin_family = AF_INET;
		my_addr.sin_addr.s_addr = INADDR_ANY;
		my_addr.sin_port = htons(myport);
		memset(my_addr.sin_zero, '\0', sizeof my_addr.sin_zero);
		//Set ID
		succ = 10000;
		pred = 10000;
	 	myid = atoi(argv[3]);
		//Set Port and address of other server
		he = gethostbyname(argv[4]);
		ringport = atoi(argv[5]);

		//Address of another server in the ring
		join_addr.sin_family = AF_INET;
		join_addr.sin_port = htons(ringport);
		join_addr.sin_addr = *((struct in_addr *)he->h_addr);
		memset(join_addr.sin_zero, '\0', sizeof join_addr.sin_zero);
		char *ip_str = inet_ntoa(join_addr.sin_addr);
		char ip_num[4];
		//write each byte of the ip in ip_num without dots
		inet_pton(AF_INET, ip_str, ip_num);
		//write complete join message
		intern[0] = 128 + 1; //intern and join()
		intern[1] = ip_num[0];
		intern[2] = ip_num[1];
		intern[3] = ip_num[2];
		intern[4] = ip_num[3];
		intern[5] = ((myport >> 8) & 0b11111111);
		intern[6] = (myport & 0b11111111);
		intern[7] = ((myid >> 8) & 0b11111111);
		intern[8] = (myid & 0b11111111);
		//set notifier
		//TODO: Join the Ring
		printf("join %s on %d\n", ip_str, ringport);
		join(join_addr, myid, intern);
	}
	//init first node in ring
	else if(argc == 4)
	{
		printf("Mainnode (with user-set ID)\n");
		myid = atoi(argv[3]);
		succ = myid;
		pred = myid;
	}
	else{
		printf("Mainnode (with standard-ID)\n");
		myid = 0;
		succ = myid;
		pred = myid;
	}
	//socket()
	sockfd = socket(PF_INET, SOCK_DGRAM, 0);
	//important infos of the server
	myport = atoi(argv[2]);
	//MY OWN ADDRESS
	my_addr.sin_family = AF_INET;
	my_addr.sin_port = htons(myport);
  my_addr.sin_addr.s_addr = INADDR_ANY;
	//inet_aton("127.0.0.1", (struct in_addr *)&my_addr.sin_addr.s_addr);
	memset(my_addr.sin_zero, '\0', sizeof my_addr.sin_zero);
  //enable many binds in a close timerange -> tell kernel to re-use port
  int useSockAgain = 1;
  setsockopt(sockfd, SOL_SOCKET, SO_REUSEADDR, &useSockAgain, sizeof(useSockAgain));
	//bind()
	if(bind(sockfd,(struct sockaddr *) &my_addr, sizeof my_addr) == -1)
	{
		printf("binding failed\n");
		exit(1);
	}
	while(1)
	{
		struct sockaddr_in recv_addr;
		struct sockaddr_in client_addr;
		socklen_t length = sizeof recv_addr;

		length = sizeof recv_addr;
		//recv()
		memset(reply, 0, 1024);
		n = recvfrom(sockfd, reply, 1024,0,  (struct sockaddr *)&recv_addr, &length);
		if(n == -1)
		{
			printf("recv failed\n");
			exit(1);
		}
		//if intern message
		if((reply[0] & 0b10000000) >= 1)
		{
			printf("Received internal message\n");
			if((reply[0] & 0b00000001) >= 1) recv_join(reply, myid);
			else if((reply[0] & 0b00000010) >= 1)
			{
				recv_notify(reply);
			}
			else if((reply[0] & 0b00000100) >= 1)
			{
				recv_stabilize(reply);
			}
		}
		//if extern message
		else
		{
			printf("---------------------------------------\n");
			printf("Received external message\n");
			//get all infos from message
			struct HashElem *elem = (struct HashElem*) malloc(sizeof(struct HashElem));
			//elem->key = malloc( sizeof( unsigned char ) * 256 );
			//elem->value = malloc(sizeof (unsigned char) * 256);
			elem->key = malloc(256);
			elem->value = malloc(256);
			struct HashElem *tempElem = (struct HashElem*) malloc(sizeof(struct HashElem));
			//tempElem->key = malloc( sizeof( unsigned char ) * 256 );
			//tempElem->value = malloc(sizeof(unsigned char) * 256);
			tempElem->key = malloc(256);
			tempElem->value = malloc(256);
			printf("Unmarshalling message\n");
			int client_id;
			int keyLen;
			int valueLen;
			char ip_client_str[16];
			char ip_client_num[4];
			int client_port;
			client_id   = reply[1];
			keyLen 		  = (reply[2] << 8) + reply[3];
			valueLen 	  = (reply[4] << 8) + reply[5];
			ip_client_num[0] = reply[6];
			ip_client_num[1] = reply[7];
			ip_client_num[2] = reply[8];
			ip_client_num[3] = reply[9];
			client_port = (reply[10] << 8) + reply[11];
			printf("Received information from client:\n");
			printf("Transaction ID: %d\n", client_id);
			int i;
			for(i = 0; i < keyLen; i++)
			{
				elem->key[i] = reply[12+i];
			}
			for(i = 0; i < valueLen; i++)
			{
				elem->value[i] = reply[12+keyLen+i];
			}
			printf("Key: %s\n", elem->key);
			printf("Value: %s\n", elem->value);
			printf("Calculating index...\n");
			int index = hash(elem->key);
			printf("index: %d\n", index);
			printf("My indexes: [%d, %d]\n", pred+1, myid);
			//check if this node has to operate
			//if this node has to operate...
			if((index <= myid && index > pred && pred < myid) // "normal" case
				|| (pred > myid && (index > pred || index <= myid))
				|| (myid == pred))
				{
				//get Operation
				if ((reply[0] & 0b00000100) >= 1) tempElem = get(elem->key, elem->value);
				if ((reply[0] & 0b00000010) >= 1) set(elem->key, elem->value);
				if ((reply[0] & 0b00000001) >= 1) del(elem);
				//set acknowledgement
				if ((reply[0] & 0b00001000) < 1) reply[0] = reply[0] + 8;
				//answers get with key and value and others without key and value
				if ((reply[0] & 0b00000100) >= 1)
				{
					if(tempElem != NULL) // aka GET;
					{
						//reply[4] = sizeof(tempElem->value) >> 8;
						//reply[5] = sizeof(tempElem->value);
						reply[4] = strlen((char*)tempElem->value) >> 8;
						reply[5] = strlen((char*)tempElem->value);
						printf("Value size: %d\n", (reply[4] << 8) + reply[5]);
						for(int i = 0; i < ((reply[4] << 8) + reply[5]); i++)
						{
							reply[12 + keyLen + i] = tempElem->value[i];
						}
					}
					else
					{
						reply[4] = 0;
						reply[5] = 0;
					}
				}
				else
				{
					reply[4] = 0;
					reply[5] = 0;
				}
				inet_ntop(AF_INET, ip_client_num, ip_client_str, INET6_ADDRSTRLEN);
				he_client              = gethostbyname(ip_client_str);
				client_addr.sin_family = AF_INET;
				client_addr.sin_port	 = htons(client_port);
				client_addr.sin_addr   = *((struct in_addr *)he_client->h_addr);
				memset(client_addr.sin_zero, '\0', sizeof client_addr.sin_zero);

				n = sendto(sockfd, reply, 1024, 0, (struct sockaddr *)&client_addr, sizeof client_addr);
				if(n == -1)
				{
					printf("send failed\n");
					exit(1);
				} else
				{
					printf("Sent message to client.\n");
					printf("---------------------------------------\n");
				}
			}
			else
			// passing received message over to successor;
			{
				printf("Sending received external message to successor...\n");
				n = sendto(sockfd, reply, 1024, 0, (struct sockaddr *)&succ_addr, sizeof(succ_addr));
				if(n == -1)
				{
					printf("send failed\n");
					exit(1);
				}
				printf("---------------------------------------\n");
			}

		}
		//END OF CLIENTREPLY
	}
	//close
	close(secondsockfd);
	close(sockfd);
	return 0;
}
