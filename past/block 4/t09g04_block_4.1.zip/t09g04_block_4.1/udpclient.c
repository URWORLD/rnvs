#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>

int main(int argc, char *argv[]) {

	if(argc < 8 || argc > 9)
	{
		printf("%d Usage: ./client <my ip> <my port> <server-hostname> <server-port> <action (get: -g, set: -s, del: -d)> <key> <value> <id>\n", argc);
		printf("If the operation is SET, the value is needed, otherwise it is not.\n");
		exit(1);
	}
	//init variables
  char key[256];
	char value[256];
	int key_len;
	int value_len;
	int id;
  int sockfd;
	int port = atoi(argv[4]);
	unsigned int myport = atoi(argv[2]);
	struct sockaddr_in their_addr, my_addr;
	struct hostent *he;
	struct hostent *he_server;
	char msg[1024];
	unsigned char server_reply[1024];
	key_len = strlen(argv[6]);
	strcpy(key, argv[6]);
	//get or delete, where only the key is necessary
	if (argc == 8)
	{
		value_len = 0;
		id = atoi(argv[7]);
		if (strcmp(argv[5], "-d") == 0)
		{
			printf("Delete request\n");
			msg[0] = 1;
		}
		else
		{
			printf("Get request\n");
			msg[0] = 4;
		}
	}
	//set, where both key and value are needed
	else
	{
		value_len = strlen(argv[7]);
		printf("Set request\n");
		strcpy(value, argv[7]);
		id = atoi(argv[8]);
		msg[0] = 2;
	}
	//my information
	he = gethostbyname(argv[1]);		// my ip address
	my_addr.sin_family = AF_INET;
	my_addr.sin_port   = htons(myport);
	my_addr.sin_addr   = *((struct in_addr *)he->h_addr);
	memset(my_addr.sin_zero, '\0', sizeof my_addr.sin_zero);

	//socket()
  if ((sockfd = socket(AF_INET, SOCK_DGRAM, 0)) == -1)
	{
    perror("socket");
    exit(1);
  }
	// bind()
	if(bind(sockfd,(struct sockaddr *) &my_addr, sizeof my_addr) == -1)
	{
		printf("binding failed\n");
		exit(1);
	}

	printf("Marshalling message\n");
	msg[1]  = id;
	msg[2]  = key_len >> 8;
	msg[3]  = key_len;
	printf("length of key: %d\n", ((msg[2] << 8) + msg[3]));
	msg[4]  = value_len >> 8;
	msg[5]  = value_len;
	printf("length of value: %d\n", ((msg[4] << 8) + msg[5]));
	char *myip_str = inet_ntoa(my_addr.sin_addr);
	char ip_my_num[4];
	inet_pton(AF_INET, myip_str, ip_my_num);
	// 6 additional bytes needed to marshall ip adress and port
	msg[6]  = ip_my_num[0];
	msg[7]  = ip_my_num[1];
	msg[8]  = ip_my_num[2];
	msg[9]  = ip_my_num[3];
	msg[10] = myport >> 8;
	msg[11] = myport;
	int i;
	for (i = 0; i < key_len; i++)
	{
		msg[12+i] = key[i];
	}
	for (i = 0; i < value_len; i++)
	{
		msg[12+key_len+i] = value[i];
	}
	//save hostname in he
  he_server = gethostbyname(argv[3]);
	//save all important server infos in their_addr
  their_addr.sin_family = AF_INET;
  their_addr.sin_port = htons(port);
  their_addr.sin_addr = *((struct in_addr *)he_server->h_addr);
  memset(their_addr.sin_zero, '\0', sizeof their_addr.sin_zero);
  //sendto()
  if(sendto(sockfd, msg, 1024, 0, (struct sockaddr*) &their_addr, sizeof their_addr) == -1)
	{
		printf("sending failed\n");
		exit(1);
	}
	printf("Sent message to Server...\n");
  //recvfrom()
	struct sockaddr_storage addr;
	socklen_t len;
	printf("Waiting for message from Server...\n");
  recvfrom(sockfd, server_reply, 1024, 0, (struct sockaddr*)&addr, &len);
	printf("Received message from Server\n");
	memset(value, 0, 256);
	if ((server_reply[0] == msg[0] + 8) && strcmp(argv[5], "-s") == 0) printf("Received SET acknowledgement.\n");
	else if ((server_reply[0] == msg[0] + 8) && strcmp(argv[5], "-d") == 0) printf("Received DEL acknowledgement.\n");
	else if ((server_reply[0] == msg[0] + 8) && strcmp(argv[5], "-g") == 0)
	{
		printf("Received GET acknowledgement.\n");
		int val_length = (server_reply[4] << 8) + server_reply[5];
		printf("Value length: %d\n", val_length);
		for (int i = 0; i < val_length; i++)
		{
			value[i] = server_reply[12 + key_len + i];
		}
		printf("Value: %s\n", value);
	}
  //close()
  close(sockfd);
  return 0;
}
