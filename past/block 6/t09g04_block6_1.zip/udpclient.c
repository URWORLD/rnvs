#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <time.h>

struct sockaddr_in their_addr;
struct hostent *he_server;
struct sockaddr_storage addr;
socklen_t len;
int sockfd;
double glob_delay;
double glob_offset;


double marshall_time(int t1,int t2,int t3,int t4,int t5,int t6,int t7,int t8)
{
	long long int sec = t4 + t3*256 + t2*256*256 + (long long int)t1 * 256*256*256;
	double ns = ((double)(t8 + t7*256 + t6*256*256 + (long long int)t5 * 256*256*256))/1000000000;
	double result = (sec+ns) - 2208988800;
	return result;

}

double calculate_delay(char* server)
{
	char msg[48];
	int i;
	struct timespec start, stop;
	double t1, t2, t3, t4;
	double delay;
	for(i = 0; i < 48; i++)
	{
		msg[i] = 0;
	}
	msg[0] = 3 + 32; // setting first byte
	unsigned char server_reply[48];

	//socket()
	if ((sockfd = socket(AF_INET, SOCK_DGRAM, 0)) == -1)
	{
		perror("socket");
		exit(1);
	}
	//printf("socket created.\n");

	//save all important server infos in their_addr DONT HARDCODE LATER
	he_server = gethostbyname(server);
	their_addr.sin_family = AF_INET;
	their_addr.sin_port = htons(123);
	their_addr.sin_addr = *((struct in_addr *)he_server->h_addr_list[0]);
	memset(their_addr.sin_zero, '\0', sizeof their_addr.sin_zero);

	//sendto()
	if(sendto(sockfd, msg, 48, 0, (struct sockaddr*) &their_addr, sizeof their_addr) == -1)
	{
		perror("Failed at send\n");
		exit(1);
	}
	clock_gettime( CLOCK_REALTIME, &start);
	t1 = start.tv_sec + ((double)start.tv_nsec / 1000000000);

	//recvfrom()
	recvfrom(sockfd, server_reply, 48, 0, (struct sockaddr*)&addr, &len);
	clock_gettime( CLOCK_REALTIME, &stop);
	t4 = stop.tv_sec + ((double)stop.tv_nsec / 1000000000);
	//Calculate times at index 32 and 40 begin / marchall msg
	t2 = marshall_time(server_reply[32],server_reply[33],server_reply[34],server_reply[35],server_reply[36],server_reply[37],server_reply[38],server_reply[39]);
	t3 = marshall_time(server_reply[40],server_reply[41],server_reply[42],server_reply[43],server_reply[44],server_reply[45],server_reply[46],server_reply[47]);
	delay =  (t4-t1) - (t3-t2);
	close(sockfd);
	return delay;
}

double calculate_all(char* server)
{
	char msg[48];
	int i;
	struct timespec start, stop, curr;
	double t1, t2, t3, t4, currentTime;
	for(i = 0; i < 48; i++)
	{
		msg[i] = 0;
	}
	msg[0] = 3 + 32; // setting first byte
	unsigned char server_reply[48];

	//socket()
	if ((sockfd = socket(AF_INET, SOCK_DGRAM, 0)) == -1)
	{
		perror("socket");
		exit(1);
	}
	//printf("socket created.\n");

	//save all important server infos in their_addr DONT HARDCODE LATER
	he_server = gethostbyname(server);
	their_addr.sin_family = AF_INET;
	their_addr.sin_port = htons(123);
	their_addr.sin_addr = *((struct in_addr *)he_server->h_addr_list[0]);
	memset(their_addr.sin_zero, '\0', sizeof their_addr.sin_zero);

	//sendto()
	if(sendto(sockfd, msg, 48, 0, (struct sockaddr*) &their_addr, sizeof their_addr) == -1)
	{
		perror("Failed at send\n");
		exit(1);
	}
	clock_gettime( CLOCK_REALTIME, &start);
	t1 = start.tv_sec + ((double)start.tv_nsec / 1000000000);

	//recvfrom()
	recvfrom(sockfd, server_reply, 48, 0, (struct sockaddr*)&addr, &len);
	clock_gettime( CLOCK_REALTIME, &stop);
	t4 = stop.tv_sec + ((double)stop.tv_nsec / 1000000000);
	//Calculate times at index 32 and 40 begin / marchall msg
	t2 = marshall_time(server_reply[32],server_reply[33],server_reply[34],server_reply[35],server_reply[36],server_reply[37],server_reply[38],server_reply[39]);
	t3 = marshall_time(server_reply[40],server_reply[41],server_reply[42],server_reply[43],server_reply[44],server_reply[45],server_reply[46],server_reply[47]);
	glob_delay =  (t4-t1) - (t3-t2);
	glob_offset = 0.5 * ((t2-t1) +(t3-t4));
	printf("t1: %lf \nt2: %lf \nt3: %lf\nt4: %lf\n", t1,t2,t3,t4);
	printf("Delay: %lf \nOffset: %lf \n", glob_delay, glob_offset);
	//correct t1 and t4
	clock_gettime( CLOCK_REALTIME, &curr);
	currentTime = curr.tv_sec + ((double)curr.tv_nsec / 1000000000);
	printf("Current time: %lf \nNew corrected time: %lf\n", currentTime, currentTime + glob_offset);
	return 0;
}
//get identifier from best rtt
int find_best(double delay_1, double delay_2, double delay_3, double delay_4)
{
	int ident = 1;
	glob_delay = delay_1;
	if(glob_delay > delay_2){
		ident = 2;
		glob_delay = delay_2;
	}
	if(glob_delay > delay_3){
		ident = 3;
		glob_delay = delay_3;
	}
	if(glob_delay > delay_4){
		ident = 4;
		glob_delay = delay_4;
	}
	printf("delay_1: %lf\ndelay_2: %lf\ndelay_3: %lf\ndelay_4: %lf\n", delay_1, delay_2, delay_3, delay_4);
	return ident;
}

int main(int argc, char *argv[]) 
{
	char best_server[100];
	int best_num;
	if(argc != 3)
	{
		printf("usage: ./client hostname port\n");
		exit(1);
	}

	double delay_1 = calculate_delay("0.de.pool.ntp.org");
	double delay_2 = calculate_delay("1.de.pool.ntp.org");
	double delay_3 = calculate_delay("2.de.pool.ntp.org");
	double delay_4 = calculate_delay("3.de.pool.ntp.org");
	//set best server 
	best_num = find_best(delay_1, delay_2, delay_3, delay_4);
	if(best_num == 1) strcpy(best_server, "0.de.pool.ntp.org");
	if(best_num == 2) strcpy(best_server, "1.de.pool.ntp.org");
	if(best_num == 3) strcpy(best_server, "2.de.pool.ntp.org");
	if(best_num == 4) strcpy(best_server, "3.de.pool.ntp.org");
	printf("%s is the best server for time synchronisation\n", best_server);
	//get glob_offset
	calculate_all(best_server);

	//close()
	close(sockfd);
  return 0;
}
