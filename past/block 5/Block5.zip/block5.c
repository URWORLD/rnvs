/** Licensed under AGPL 3.0. (C) 2010 David Moreno Montero. http://coralbits.com */
#include <onion/onion.h>
#include <onion/log.h>
#include <signal.h>
#include <netdb.h>

#include "favicon.h"

int favicon(void *p, onion_request *req, onion_response *res){

	onion_response_set_header(res, "Server", "Super Rechnernetze Server TxxGyy v0.1");
	onion_response_set_header(res, "Content-Type", "image/x-icon");

	if (onion_response_write_headers(res)==OR_SKIP_CONTENT) // Maybe it was HEAD.
		return OCS_PROCESSED;

	onion_response_write(res, (const char *)favicon_ico, favicon_ico_len);

	return OCS_PROCESSED;
}

int hello(void *p, onion_request *req, onion_response *res){
	onion_response_write0(res,"Hello world");
	if (onion_request_get_query(req, "1")){
		onion_response_printf(res, "<p>Path: %s", onion_request_get_query(req, "1"));
	}
	onion_response_printf(res,"<p>Client description: %s",onion_request_get_client_description(req));

	onion_response_set_header(res, "Server", "Super Rechnernetze Server TxxGyy v0.1");

	return OCS_PROCESSED;
}

onion *o=NULL;

static void shutdown_server(int _){
	if (o)
		onion_listen_stop(o);
}

int main(int argc, char **argv){
	signal(SIGINT,shutdown_server);
	signal(SIGTERM,shutdown_server);

	o=onion_new(O_POOL);
	onion_set_timeout(o, 5000);
	onion_set_hostname(o,"0.0.0.0");
	onion_set_port(o, "4711");
	onion_url *urls=onion_root_url(o);

	onion_url_add(urls, "favicon.ico", favicon);
	onion_url_add(urls, "", hello);
	onion_url_add(urls, "^(.*)$", hello);

	onion_listen(o);
	onion_free(o);
	return 0;
}
